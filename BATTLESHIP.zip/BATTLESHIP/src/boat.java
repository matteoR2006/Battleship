public class boat {
    boolean alive = true;
    int size, width, height = 50, cells;
    String fileName;
    int[] xPositions;
    int yPosition;

    public boat(int size) {
        this.size = size;
        this.xPositions = new int[size];
        if (size == 3) {
            width = 150;
            fileName = "3x1boat.png";
            cells = 3;
        } else if (size == 4) {
            width = 200;
            fileName = "4x1boat.png";
            cells = 4;
        } else if (size == 5) {
            width = 250;
            fileName = "5x1boat.png";
            cells = 5;
        }


    }
}
