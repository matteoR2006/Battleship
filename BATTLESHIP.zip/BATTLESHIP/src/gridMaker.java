import javax.swing.*;
import java.awt.Graphics;


public class gridMaker extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawString("A", 70, 40);
        g.drawString("B", 120, 40);
        g.drawString("C", 170, 40);
        g.drawString("D", 220, 40);
        g.drawString("E", 270, 40);
        g.drawString("F", 320, 40);
        g.drawString("G", 370, 40);
        g.drawString("H", 420, 40);
        g.drawString("I", 470, 40);
        g.drawString("J", 520, 40);
        g.drawString("1", 30, 80);
        g.drawString("2", 30, 130);
        g.drawString("3", 30, 180);
        g.drawString("4", 30, 230);
        g.drawString("5", 30, 280);
        g.drawString("6", 30, 330);
        g.drawString("7", 30, 380);
        g.drawString("8", 30, 430);
        g.drawString("9", 30, 480);
        g.drawString("10", 25, 530);
        int xx1 = 50, xy1 = 50, xx2 = 550, xy2 = 50;
        for (int x = 0; x < 11; x++) {
            g.drawLine(xx1, xy1, xx2, xy2);
            xy1 += 50;
            xy2 += 50;
        }
        int yx1 = 50, yy1 = 50, yx2 = 50, yy2 = 550;
        for (int y = 0; y < 11; y++) {
            g.drawLine(yx1, yy1, yx2, yy2);
            yx1 += 50;
            yx2 += 50;
        }

    }
}

